-- Ejecutar en MySQL Workbench sobre la base de datos dbsistema.
USE dbsistema;

-- Usuarios con contraseñas almacenadas como hash PBKDF2 (nunca texto plano).
CREATE TABLE IF NOT EXISTS usuarios_login (
    id_usuario BIGINT NOT NULL AUTO_INCREMENT,
    correo VARCHAR(254) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_usuario),
    UNIQUE KEY uq_usuarios_login_correo (correo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Historial de registros e intentos de inicio de sesión.
CREATE TABLE IF NOT EXISTS registro_correos (
    id_registro BIGINT NOT NULL AUTO_INCREMENT,
    correo VARCHAR(254) NOT NULL,
    tipo_acceso ENUM('REGISTRO', 'INICIO_SESION') NOT NULL,
    exitoso TINYINT(1) NOT NULL DEFAULT 1,
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_registro),
    INDEX idx_registro_correos_correo (correo),
    INDEX idx_registro_correos_fecha (fecha_registro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Si ya existía la tabla creada en la versión anterior, agrega la columna exitoso.
SET @col_existe = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'registro_correos'
      AND COLUMN_NAME = 'exitoso'
);
SET @sql_alter = IF(@col_existe = 0,
    'ALTER TABLE registro_correos ADD COLUMN exitoso TINYINT(1) NOT NULL DEFAULT 1 AFTER tipo_acceso',
    'SELECT ''La columna exitoso ya existe'' AS mensaje');
PREPARE stmt FROM @sql_alter;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Consultar las cuentas creadas (no muestra contraseñas originales, solo hashes).
-- SELECT id_usuario, correo, fecha_registro FROM usuarios_login ORDER BY fecha_registro DESC;
-- Consultar el historial de registros e intentos de acceso.
-- SELECT * FROM registro_correos ORDER BY fecha_registro DESC;

package basededatos;

import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Utilidades para almacenar contraseñas con PBKDF2; nunca guarda texto plano. */
public final class PasswordUtil {
    private static final int ITERACIONES = 210000;
    private static final int BITS = 256;
    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordUtil() { }

    public static String generarHash(char[] password) throws Exception {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        byte[] hash = derivar(password, salt);
        return ITERACIONES + ":" + Base64.getEncoder().encodeToString(salt)
                + ":" + Base64.getEncoder().encodeToString(hash);
    }

    public static boolean verificar(char[] password, String almacenado) throws Exception {
        if (almacenado == null) return false;
        String[] partes = almacenado.split(":");
        if (partes.length != 3) return false;
        int iteraciones = Integer.parseInt(partes[0]);
        byte[] salt = Base64.getDecoder().decode(partes[1]);
        byte[] esperado = Base64.getDecoder().decode(partes[2]);
        byte[] obtenido = derivar(password, salt, iteraciones, esperado.length * 8);
        if (obtenido.length != esperado.length) return false;
        int diferencia = 0;
        for (int i = 0; i < esperado.length; i++) diferencia |= esperado[i] ^ obtenido[i];
        return diferencia == 0;
    }

    private static byte[] derivar(char[] password, byte[] salt) throws Exception {
        return derivar(password, salt, ITERACIONES, BITS);
    }

    private static byte[] derivar(char[] password, byte[] salt, int iteraciones, int bits) throws Exception {
        KeySpec spec = new PBEKeySpec(password, salt, iteraciones, bits);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            ((PBEKeySpec) spec).clearPassword();
        }
    }
}

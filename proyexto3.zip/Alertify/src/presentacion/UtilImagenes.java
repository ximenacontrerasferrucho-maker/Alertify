package presentacion;

import java.awt.Image;
import java.io.File;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 * Carga de imágenes de forma robusta para NetBeans.
 * Prueba classpath y también la carpeta del proyecto (src/imagenes).
 */
public class UtilImagenes {

    public static ImageIcon cargar(String nombreArchivo) {
        URL url = null;

        // 1. Classpath absoluto
        url = UtilImagenes.class.getResource("/imagenes/" + nombreArchivo);

        // 2. Relativo al paquete
        if (url == null) {
            url = UtilImagenes.class.getResource("../imagenes/" + nombreArchivo);
        }

        // 3. ClassLoader del sistema
        if (url == null) {
            url = ClassLoader.getSystemResource("imagenes/" + nombreArchivo);
        }

        // 4. ClassLoader del hilo
        if (url == null) {
            url = Thread.currentThread().getContextClassLoader().getResource("imagenes/" + nombreArchivo);
        }

        if (url != null) {
            return new ImageIcon(url);
        }

        // 5. Sistema de archivos (funciona al ejecutar desde NetBeans con working dir = proyecto)
        String[] rutas = {
            "src/imagenes/" + nombreArchivo,
            "imagenes/" + nombreArchivo,
            System.getProperty("user.dir") + File.separator + "src" + File.separator + "imagenes" + File.separator + nombreArchivo,
            System.getProperty("user.dir") + File.separator + "imagenes" + File.separator + nombreArchivo
        };

        for (String ruta : rutas) {
            File f = new File(ruta);
            if (f.exists() && f.isFile()) {
                System.out.println("Imagen cargada desde archivo: " + f.getAbsolutePath());
                return new ImageIcon(f.getAbsolutePath());
            }
        }

        // No se encontró
        System.err.println("ERROR: No se encontró la imagen: " + nombreArchivo);
        System.err.println("user.dir = " + System.getProperty("user.dir"));
        for (String ruta : rutas) {
            System.err.println("  Probado: " + new File(ruta).getAbsolutePath() + " existe=" + new File(ruta).exists());
        }

        JOptionPane.showMessageDialog(null,
                "No se encontró la imagen: " + nombreArchivo +
                "\n\nuser.dir = " + System.getProperty("user.dir") +
                "\n\nSolución:\n" +
                "1. Clic derecho en el proyecto MovileSeguro → Clean and Build\n" +
                "2. Luego clic derecho en el proyecto → Run\n" +
                "   (NO uses Run File sobre Inicio.java)",
                "Imagen no encontrada",
                JOptionPane.ERROR_MESSAGE);

        return new ImageIcon();
    }
}

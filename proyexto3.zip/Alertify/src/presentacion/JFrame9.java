package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame9 extends JFrame {

    public JFrame9() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Perfil / Configuración");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(242, 425));

        JLabel imagen = new JLabel(UtilImagenes.cargar("9.png"));
        imagen.setBounds(0, 0, 242, 425);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Mi información
        JButton boton1 = crearBoton(18, 104, 206, 36);
        boton1.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Nombre: Camila\nCorreo: camila@gmail.com\n(Edición de perfil próximamente)",
                "Mi información", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: Métodos de pago
        JButton boton2 = crearBoton(18, 146, 206, 36);
        boton2.addActionListener(e -> {
            new JFrame10().setVisible(true); // reutilizamos notificaciones o podrías ir a pago
            dispose();
        });
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: Notificaciones
        JButton boton3 = crearBoton(18, 188, 206, 36);
        boton3.addActionListener(e -> {
            new JFrame10().setVisible(true);
            dispose();
        });
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        // boton4: Privacidad
        JButton boton4 = crearBoton(18, 230, 206, 36);
        boton4.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Configuración de privacidad.\nTus datos están protegidos.", "Privacidad", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton4, JLayeredPane.PALETTE_LAYER);

        // boton5: Ayuda y soporte
        JButton boton5 = crearBoton(18, 272, 206, 36);
        boton5.addActionListener(e -> {
            new JFrame7().setVisible(true);
            dispose();
        });
        capas.add(boton5, JLayeredPane.PALETTE_LAYER);

        // boton6: Cerrar sesión
        JButton boton6 = crearBoton(18, 314, 206, 36);
        boton6.addActionListener(e -> {
            int resp = JOptionPane.showConfirmDialog(this, "¿Cerrar sesión?", "Salir", JOptionPane.YES_NO_OPTION);
            if (resp == JOptionPane.YES_OPTION) {
                new JFrame1().setVisible(true);
                dispose();
            }
        });
        capas.add(boton6, JLayeredPane.PALETTE_LAYER);

        // boton7: Bottom nav - Mapa
        JButton boton7 = crearBoton(14, 382, 45, 36);
        boton7.addActionListener(e -> {
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton7, JLayeredPane.PALETTE_LAYER);

        // boton8: Bottom nav - Seguridad
        JButton boton8 = crearBoton(64, 382, 45, 36);
        boton8.addActionListener(e -> {
            new JFrame7().setVisible(true);
            dispose();
        });
        capas.add(boton8, JLayeredPane.PALETTE_LAYER);

        // boton9: Bottom nav - Comunidad
        JButton boton9 = crearBoton(114, 382, 45, 36);
        boton9.addActionListener(e -> {
            new JFrame8().setVisible(true);
            dispose();
        });
        capas.add(boton9, JLayeredPane.PALETTE_LAYER);

        // boton10: Bottom nav - Perfil (actual)
        JButton boton10 = crearBoton(164, 382, 45, 36);
        boton10.addActionListener(e -> {
            // Ya estamos aquí
        });
        capas.add(boton10, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame9().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

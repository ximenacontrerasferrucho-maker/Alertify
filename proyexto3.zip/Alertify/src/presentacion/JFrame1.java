package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame1 extends JFrame {

    public JFrame1() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Tu Viaje Seguro");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(270, 480));

        JLabel imagen = new JLabel(UtilImagenes.cargar("1.png"));
        imagen.setBounds(0, 0, 270, 480);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // Botón superior (Iniciar sesión / Continuar)
        JButton boton1 = crearBoton(38, 311, 194, 37);
        boton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new JFrame2().setVisible(true);
                dispose();
            }
        });
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // Botón inferior (también lleva al mapa principal)
        JButton boton2 = crearBoton(39, 357, 194, 36);
        boton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new JFrame2().setVisible(true);
                dispose();
            }
        });
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // Enlace "Regístrate"
        JButton boton3 = crearBoton(140, 410, 75, 24);
        boton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(JFrame1.this,
                        "Funcionalidad de registro próximamente.\nPuedes continuar como invitado.",
                        "Registro", JOptionPane.INFORMATION_MESSAGE);
                new JFrame2().setVisible(true);
                dispose();
            }
        });
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame1().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

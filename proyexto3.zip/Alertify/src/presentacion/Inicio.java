package presentacion;

public class Inicio {
    public static void main(String[] args) {
        // Look and Feel del sistema para mejor apariencia
        try {
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Ignorar si falla
        }
        java.awt.EventQueue.invokeLater(() -> new JFrame1().setVisible(true));
    }
}

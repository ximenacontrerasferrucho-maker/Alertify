package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame4 extends JFrame {

    public JFrame4() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Detalle de ruta");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(380, 642));

        JLabel imagen = new JLabel(UtilImagenes.cargar("4.png"));
        imagen.setBounds(0, 0, 380, 642);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Atrás ←
        JButton boton1 = crearBoton(21, 54, 36, 31);
        boton1.addActionListener(e -> {
            new JFrame3().setVisible(true);
            dispose();
        });
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: Compartir
        JButton boton2 = crearBoton(275, 89, 69, 34);
        boton2.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Ruta compartida correctamente.", "Compartir", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: BOTÓN AQUÍ inferior → Iniciar / volver al mapa
        JButton boton3 = crearBoton(24, 548, 337, 54);
        boton3.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "¡Ruta iniciada! Viaja con seguridad.", "Navegación", JOptionPane.INFORMATION_MESSAGE);
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame4().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

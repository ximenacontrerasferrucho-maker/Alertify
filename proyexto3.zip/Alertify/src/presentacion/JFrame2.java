package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame2 extends JFrame {

    public JFrame2() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Pantalla principal / Mapa");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(380, 650));

        JLabel imagen = new JLabel(UtilImagenes.cargar("2.png"));
        imagen.setBounds(0, 0, 380, 650);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Compartir (arriba derecha)
        JButton boton1 = crearBoton(300, 111, 64, 30);
        boton1.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Función de compartir ruta próximamente.", "Compartir", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: BOTÓN AQUÍ de la tarjeta de ruta → Detalle de ruta
        JButton boton2 = crearBoton(295, 250, 67, 30);
        boton2.addActionListener(e -> {
            new JFrame4().setVisible(true);
            dispose();
        });
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: Reportar riesgo
        JButton boton3 = crearBoton(27, 306, 67, 65);
        boton3.addActionListener(e -> {
            new JFrame6().setVisible(true);
            dispose();
        });
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        // boton4: Revisar ruta → Planificar ruta
        JButton boton4 = crearBoton(101, 306, 68, 65);
        boton4.addActionListener(e -> {
            new JFrame3().setVisible(true);
            dispose();
        });
        capas.add(boton4, JLayeredPane.PALETTE_LAYER);

        // boton5: Ayuda rápida → Seguridad / ayuda
        JButton boton5 = crearBoton(174, 306, 67, 65);
        boton5.addActionListener(e -> {
            new JFrame7().setVisible(true);
            dispose();
        });
        capas.add(boton5, JLayeredPane.PALETTE_LAYER);

        // boton6: Bottom nav - Mapa (actual)
        JButton boton6 = crearBoton(15, 401, 44, 38);
        boton6.addActionListener(e -> {
            // Ya estamos en el mapa
        });
        capas.add(boton6, JLayeredPane.PALETTE_LAYER);

        // boton7: Bottom nav - Seguridad
        JButton boton7 = crearBoton(66, 401, 57, 38);
        boton7.addActionListener(e -> {
            new JFrame7().setVisible(true);
            dispose();
        });
        capas.add(boton7, JLayeredPane.PALETTE_LAYER);

        // boton8: Bottom nav - Comunidad
        JButton boton8 = crearBoton(130, 401, 57, 38);
        boton8.addActionListener(e -> {
            new JFrame8().setVisible(true);
            dispose();
        });
        capas.add(boton8, JLayeredPane.PALETTE_LAYER);

        // boton9: Bottom nav - Perfil
        JButton boton9 = crearBoton(193, 401, 45, 38);
        boton9.addActionListener(e -> {
            new JFrame9().setVisible(true);
            dispose();
        });
        capas.add(boton9, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame2().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

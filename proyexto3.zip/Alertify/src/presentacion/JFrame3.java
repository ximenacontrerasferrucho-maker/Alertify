package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame3 extends JFrame {

    public JFrame3() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Planificar ruta");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(367, 647));

        JLabel imagen = new JLabel(UtilImagenes.cargar("3.png"));
        imagen.setBounds(0, 0, 367, 647);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Atrás ←
        JButton boton1 = crearBoton(24, 55, 35, 32);
        boton1.addActionListener(e -> {
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: Icono ubicación / destino
        JButton boton2 = crearBoton(304, 145, 35, 33);
        boton2.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Selecciona el destino en el mapa.", "Destino", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: Auto
        JButton boton3 = crearBoton(23, 178, 81, 34);
        boton3.addActionListener(e -> JOptionPane.showMessageDialog(this, "Modo de transporte: Auto seleccionado.", "Transporte", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        // boton4: Bus
        JButton boton4 = crearBoton(106, 178, 80, 34);
        boton4.addActionListener(e -> JOptionPane.showMessageDialog(this, "Modo de transporte: Bus seleccionado.", "Transporte", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton4, JLayeredPane.PALETTE_LAYER);

        // boton5: Bici
        JButton boton5 = crearBoton(189, 178, 72, 34);
        boton5.addActionListener(e -> JOptionPane.showMessageDialog(this, "Modo de transporte: Bici seleccionado.", "Transporte", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton5, JLayeredPane.PALETTE_LAYER);

        // boton6: Caminata
        JButton boton6 = crearBoton(264, 178, 77, 34);
        boton6.addActionListener(e -> JOptionPane.showMessageDialog(this, "Modo de transporte: Caminata seleccionado.", "Transporte", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton6, JLayeredPane.PALETTE_LAYER);

        // boton7: Ruta segura → Detalle
        JButton boton7 = crearBoton(23, 224, 322, 69);
        boton7.addActionListener(e -> {
            new JFrame4().setVisible(true);
            dispose();
        });
        capas.add(boton7, JLayeredPane.PALETTE_LAYER);

        // boton8: Ruta rápida → Detalle
        JButton boton8 = crearBoton(23, 302, 322, 70);
        boton8.addActionListener(e -> {
            new JFrame4().setVisible(true);
            dispose();
        });
        capas.add(boton8, JLayeredPane.PALETTE_LAYER);

        // boton9: Ruta económica → Detalle
        JButton boton9 = crearBoton(23, 379, 322, 70);
        boton9.addActionListener(e -> {
            new JFrame4().setVisible(true);
            dispose();
        });
        capas.add(boton9, JLayeredPane.PALETTE_LAYER);

        // boton10: BOTÓN AQUÍ inferior → Detalle de ruta
        JButton boton10 = crearBoton(24, 563, 320, 56);
        boton10.addActionListener(e -> {
            new JFrame4().setVisible(true);
            dispose();
        });
        capas.add(boton10, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame3().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

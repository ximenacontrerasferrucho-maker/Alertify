package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame6 extends JFrame {

    public JFrame6() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Reportar riesgo");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(235, 425));

        JLabel imagen = new JLabel(UtilImagenes.cargar("6.png"));
        imagen.setBounds(0, 0, 235, 425);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Atrás ←
        JButton boton1 = crearBoton(20, 51, 35, 31);
        boton1.addActionListener(e -> {
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: Accidente
        JButton boton2 = crearBoton(32, 174, 96, 73);
        boton2.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Riesgo 'Accidente' reportado.\n¡Gracias por ayudar a la comunidad!", "Reporte", JOptionPane.INFORMATION_MESSAGE);
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: Obra en la vía
        JButton boton3 = crearBoton(136, 174, 96, 73);
        boton3.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Riesgo 'Obra en la vía' reportado.\n¡Gracias por ayudar a la comunidad!", "Reporte", JOptionPane.INFORMATION_MESSAGE);
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        // boton4: Inseguridad
        JButton boton4 = crearBoton(32, 255, 96, 74);
        boton4.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Riesgo 'Inseguridad' reportado.\n¡Gracias por ayudar a la comunidad!", "Reporte", JOptionPane.INFORMATION_MESSAGE);
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton4, JLayeredPane.PALETTE_LAYER);

        // boton5: Otro
        JButton boton5 = crearBoton(136, 255, 96, 74);
        boton5.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Riesgo 'Otro' reportado.\n¡Gracias por ayudar a la comunidad!", "Reporte", JOptionPane.INFORMATION_MESSAGE);
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton5, JLayeredPane.PALETTE_LAYER);

        // boton6: BOTÓN AQUÍ inferior
        JButton boton6 = crearBoton(21, 367, 214, 44);
        boton6.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Selecciona un tipo de riesgo primero.", "Aviso", JOptionPane.WARNING_MESSAGE);
        });
        capas.add(boton6, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame6().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame10 extends JFrame {

    public JFrame10() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Notificaciones / Ayuda");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(241, 421));

        JLabel imagen = new JLabel(UtilImagenes.cargar("10.png"));
        imagen.setBounds(0, 0, 241, 421);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Atrás ←
        JButton boton1 = crearBoton(19, 51, 34, 30);
        boton1.addActionListener(e -> {
            new JFrame9().setVisible(true);
            dispose();
        });
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: Tab Todas
        JButton boton2 = crearBoton(18, 78, 68, 31);
        boton2.addActionListener(e -> JOptionPane.showMessageDialog(this, "Mostrando todas las notificaciones.", "Notificaciones", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: Tab Alertas
        JButton boton3 = crearBoton(88, 78, 68, 31);
        boton3.addActionListener(e -> {
            new JFrame5().setVisible(true);
            dispose();
        });
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        // boton4: Tab Comunidad
        JButton boton4 = crearBoton(158, 78, 68, 31);
        boton4.addActionListener(e -> {
            new JFrame8().setVisible(true);
            dispose();
        });
        capas.add(boton4, JLayeredPane.PALETTE_LAYER);

        // boton5 a boton9: Items de notificación (solo feedback)
        JButton boton5 = crearBoton(18, 120, 207, 47);
        boton5.addActionListener(e -> JOptionPane.showMessageDialog(this, "Lluvia intensa en Alto del Síga.\nHace 5 min", "Alerta", JOptionPane.WARNING_MESSAGE));
        capas.add(boton5, JLayeredPane.PALETTE_LAYER);

        JButton boton6 = crearBoton(18, 174, 207, 47);
        boton6.addActionListener(e -> JOptionPane.showMessageDialog(this, "Tu ruta fue actualizada.\nHace 12 min", "Ruta", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton6, JLayeredPane.PALETTE_LAYER);

        JButton boton7 = crearBoton(18, 228, 207, 47);
        boton7.addActionListener(e -> JOptionPane.showMessageDialog(this, "Obra vial en la Av. 68.\nHace 28 min", "Obra", JOptionPane.WARNING_MESSAGE));
        capas.add(boton7, JLayeredPane.PALETTE_LAYER);

        JButton boton8 = crearBoton(18, 282, 207, 47);
        boton8.addActionListener(e -> JOptionPane.showMessageDialog(this, "Nuevo mensaje en la comunidad.\nHace 1 h", "Comunidad", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton8, JLayeredPane.PALETTE_LAYER);

        JButton boton9 = crearBoton(18, 336, 207, 47);
        boton9.addActionListener(e -> JOptionPane.showMessageDialog(this, "Recordatorio: revisa tu ruta.\nHace 2 h", "Recordatorio", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton9, JLayeredPane.PALETTE_LAYER);

        // boton10: Bottom nav - Mapa
        JButton boton10 = crearBoton(14, 385, 45, 36);
        boton10.addActionListener(e -> {
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton10, JLayeredPane.PALETTE_LAYER);

        // boton11: Bottom nav - Seguridad
        JButton boton11 = crearBoton(64, 385, 45, 36);
        boton11.addActionListener(e -> {
            new JFrame7().setVisible(true);
            dispose();
        });
        capas.add(boton11, JLayeredPane.PALETTE_LAYER);

        // boton12: Bottom nav - Notificaciones (actual)
        JButton boton12 = crearBoton(114, 385, 45, 36);
        boton12.addActionListener(e -> {
            // Ya estamos aquí
        });
        capas.add(boton12, JLayeredPane.PALETTE_LAYER);

        // boton13: Bottom nav - Perfil
        JButton boton13 = crearBoton(164, 385, 45, 36);
        boton13.addActionListener(e -> {
            new JFrame9().setVisible(true);
            dispose();
        });
        capas.add(boton13, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame10().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

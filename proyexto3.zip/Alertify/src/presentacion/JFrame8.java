package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame8 extends JFrame {

    public JFrame8() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Comunidad");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(232, 426));

        JLabel imagen = new JLabel(UtilImagenes.cargar("8.png"));
        imagen.setBounds(0, 0, 232, 426);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Tab Todos
        JButton boton1 = crearBoton(22, 52, 73, 30);
        boton1.addActionListener(e -> JOptionPane.showMessageDialog(this, "Mostrando todos los posts de la comunidad.", "Comunidad", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: Tab Reportes
        JButton boton2 = crearBoton(98, 52, 73, 30);
        boton2.addActionListener(e -> JOptionPane.showMessageDialog(this, "Mostrando solo reportes de la comunidad.", "Reportes", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: Tab Consejos
        JButton boton3 = crearBoton(174, 52, 73, 30);
        boton3.addActionListener(e -> JOptionPane.showMessageDialog(this, "Mostrando consejos de la comunidad.", "Consejos", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        // boton4: Bottom nav - Mapa
        JButton boton4 = crearBoton(18, 355, 46, 36);
        boton4.addActionListener(e -> {
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton4, JLayeredPane.PALETTE_LAYER);

        // boton5: Bottom nav - Seguridad
        JButton boton5 = crearBoton(67, 355, 46, 36);
        boton5.addActionListener(e -> {
            new JFrame7().setVisible(true);
            dispose();
        });
        capas.add(boton5, JLayeredPane.PALETTE_LAYER);

        // boton6: Bottom nav - Comunidad (actual)
        JButton boton6 = crearBoton(117, 355, 46, 36);
        boton6.addActionListener(e -> {
            // Ya estamos aquí
        });
        capas.add(boton6, JLayeredPane.PALETTE_LAYER);

        // boton7: Bottom nav - Perfil
        JButton boton7 = crearBoton(166, 355, 46, 36);
        boton7.addActionListener(e -> {
            new JFrame9().setVisible(true);
            dispose();
        });
        capas.add(boton7, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame8().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

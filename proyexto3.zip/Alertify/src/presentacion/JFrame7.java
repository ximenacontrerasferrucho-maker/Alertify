package presentacion;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JFrame7 extends JFrame {

    public JFrame7() {
        initComponents(); // bloque generado para NetBeans

        setTitle("Movile - Seguridad / Ayuda");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        JLayeredPane capas = new JLayeredPane();
        capas.setLayout(null);
        capas.setPreferredSize(new java.awt.Dimension(232, 422));

        JLabel imagen = new JLabel(UtilImagenes.cargar("7.png"));
        imagen.setBounds(0, 0, 232, 422);
        capas.add(imagen, JLayeredPane.DEFAULT_LAYER);

        // boton1: Botón de pánico
        JButton boton1 = crearBoton(17, 82, 97, 79);
        boton1.addActionListener(e -> {
            int resp = JOptionPane.showConfirmDialog(this,
                    "¿Activar botón de pánico?\nSe enviará tu ubicación a contactos de emergencia.",
                    "Botón de pánico", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (resp == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "¡Alerta de pánico enviada!\nAyuda en camino.", "Pánico", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        capas.add(boton1, JLayeredPane.PALETTE_LAYER);

        // boton2: Compartir ubicación
        JButton boton2 = crearBoton(121, 82, 97, 79);
        boton2.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Ubicación compartida con tus contactos de confianza.", "Ubicación", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton2, JLayeredPane.PALETTE_LAYER);

        // boton3: Llamar a emergencia
        JButton boton3 = crearBoton(17, 166, 97, 80);
        boton3.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Llamando a emergencias (123)...\n(Simulación)", "Emergencia", JOptionPane.WARNING_MESSAGE));
        capas.add(boton3, JLayeredPane.PALETTE_LAYER);

        // boton4: Chat de ayuda
        JButton boton4 = crearBoton(121, 166, 97, 80);
        boton4.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Chat de ayuda conectado.\nUn agente te atenderá en breve.", "Chat", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton4, JLayeredPane.PALETTE_LAYER);

        // boton5: Consejos de seguridad
        JButton boton5 = crearBoton(17, 252, 201, 50);
        boton5.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Consejos de seguridad:\n• Comparte tu ruta\n• Evita zonas de riesgo\n• Mantén la batería cargada\n• Usa el botón de pánico si es necesario",
                "Consejos", JOptionPane.INFORMATION_MESSAGE));
        capas.add(boton5, JLayeredPane.PALETTE_LAYER);

        // boton6: Bottom nav - Mapa
        JButton boton6 = crearBoton(14, 350, 46, 36);
        boton6.addActionListener(e -> {
            new JFrame2().setVisible(true);
            dispose();
        });
        capas.add(boton6, JLayeredPane.PALETTE_LAYER);

        // boton7: Bottom nav - Seguridad (actual)
        JButton boton7 = crearBoton(63, 350, 46, 36);
        boton7.addActionListener(e -> {
            // Ya estamos aquí
        });
        capas.add(boton7, JLayeredPane.PALETTE_LAYER);

        // boton8: Bottom nav - Comunidad
        JButton boton8 = crearBoton(115, 350, 46, 36);
        boton8.addActionListener(e -> {
            new JFrame8().setVisible(true);
            dispose();
        });
        capas.add(boton8, JLayeredPane.PALETTE_LAYER);

        // boton9: Bottom nav - Perfil
        JButton boton9 = crearBoton(166, 350, 47, 36);
        boton9.addActionListener(e -> {
            new JFrame9().setVisible(true);
            dispose();
        });
        capas.add(boton9, JLayeredPane.PALETTE_LAYER);

        setContentPane(capas);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(int x, int y, int ancho, int alto) {
        JButton boton = new JButton();
        boton.setBounds(x, y, ancho, alto);
        boton.setText("");
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        boton.setFocusPainted(false);
        boton.setOpaque(false);
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        return boton;
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new JFrame7().setVisible(true));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

}

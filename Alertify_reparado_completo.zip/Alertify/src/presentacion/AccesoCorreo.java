package presentacion;

import basededatos.RegistroCorreoDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/** Ventana de registro e inicio de sesión de Alertify. */
public class AccesoCorreo extends JDialog {

    private final JTextField campoCorreo = new JTextField(24);
    private final JPasswordField campoPassword = new JPasswordField(24);
    private final String tipoAcceso;

    public AccesoCorreo(java.awt.Frame padre, String tipoAcceso) {
        super(padre, true);
        this.tipoAcceso = tipoAcceso;
        boolean esRegistro = "REGISTRO".equals(tipoAcceso);

        setTitle(esRegistro ? "Registro - Alertify" : "Inicio de sesión - Alertify");
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));

        JLabel titulo = new JLabel(esRegistro ? "Crea tu cuenta en Alertify" : "Ingresa a tu cuenta", SwingConstants.CENTER);
        JPanel centro = new JPanel(new GridLayout(4, 1, 6, 6));
        centro.add(new JLabel("Correo electrónico:"));
        centro.add(campoCorreo);
        centro.add(new JLabel("Contraseña:"));
        centro.add(campoPassword);
        centro.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 18, 4, 18));

        JButton continuar = new JButton(esRegistro ? "Crear cuenta" : "Iniciar sesión");
        JButton cancelar = new JButton("Cancelar");
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botones.add(continuar);
        botones.add(cancelar);

        add(titulo, BorderLayout.NORTH);
        add(centro, BorderLayout.CENTER);
        add(botones, BorderLayout.SOUTH);

        continuar.addActionListener(e -> procesarAcceso());
        cancelar.addActionListener(e -> {
            dispose();
            if (padre != null) {
                padre.setVisible(true);
                padre.toFront();
            }
        });
        getRootPane().setDefaultButton(continuar);
        pack();
        setResizable(false);
        setLocationRelativeTo(padre);
    }

    private void procesarAcceso() {
        String correo = campoCorreo.getText().trim();
        char[] password = campoPassword.getPassword();
        if (correo.isEmpty() || !correo.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            JOptionPane.showMessageDialog(this, "Ingresa un correo electrónico válido.", "Correo inválido", JOptionPane.WARNING_MESSAGE);
            campoCorreo.requestFocus();
            Arrays.fill(password, '\0');
            return;
        }
        if (password.length < 8) {
            JOptionPane.showMessageDialog(this, "La contraseña debe tener al menos 8 caracteres.", "Contraseña inválida", JOptionPane.WARNING_MESSAGE);
            campoPassword.requestFocus();
            Arrays.fill(password, '\0');
            return;
        }

        try {
            RegistroCorreoDAO dao = new RegistroCorreoDAO();
            if ("REGISTRO".equals(tipoAcceso)) {
                dao.registrar(correo, password);
                JOptionPane.showMessageDialog(this, "Cuenta creada correctamente. Ya puedes ingresar a Alertify.", "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
                java.awt.Window ventanaAnterior = getOwner();
                dispose();
                java.awt.EventQueue.invokeLater(() -> {
                    if (ventanaAnterior != null) ventanaAnterior.dispose();
                    new JFrame1().setVisible(true);
                });
            } else {
                boolean autenticado = dao.iniciarSesion(correo, password);
                if (autenticado) {
                    JOptionPane.showMessageDialog(this, "Inicio de sesión correcto.", "Alertify", JOptionPane.INFORMATION_MESSAGE);
                    // Cerrar primero el diálogo modal y la pantalla de bienvenida.
                    // Abrir el mapa en el siguiente ciclo de Swing evita que la ventana
                    // principal quede bloqueada por el diálogo modal.
                    java.awt.Window ventanaAnterior = getOwner();
                    dispose();
                    java.awt.EventQueue.invokeLater(() -> {
                        if (ventanaAnterior != null) ventanaAnterior.dispose();
                        JFrame2 pantallaPrincipal = new JFrame2();
                        pantallaPrincipal.setLocationRelativeTo(null);
                        pantallaPrincipal.setVisible(true);
                        pantallaPrincipal.toFront();
                    });
                } else {
                    JOptionPane.showMessageDialog(this, "Correo o contraseña incorrectos.", "No se pudo iniciar sesión", JOptionPane.WARNING_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            String mensaje = ex.getErrorCode() == 1062
                    ? "Este correo ya tiene una cuenta registrada."
                    : "No se pudo completar la operación en MySQL. Verifica que ejecutaste el script SQL y que el servidor esté activo.\n\nDetalle: " + ex.getMessage();
            JOptionPane.showMessageDialog(this, mensaje, "Base de datos", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "No se pudo procesar la contraseña.\n\nDetalle: " + ex.getMessage(), "Alertify", JOptionPane.ERROR_MESSAGE);
        } finally {
            Arrays.fill(password, '\0');
            campoPassword.setText("");
        }
    }
}

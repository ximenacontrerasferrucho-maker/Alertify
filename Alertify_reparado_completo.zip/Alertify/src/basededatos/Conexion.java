package basededatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Gestiona la conexión con la base de datos Alertify. */
public class Conexion {
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/dbsistema?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public Connection cadena;
    private static Conexion instancia;

    private Conexion() {
        cadena = null;
    }

    /**
     * Devuelve una conexión nueva. Si MySQL o el controlador no están disponibles,
     * devuelve null sin cerrar toda la aplicación.
     */
    public synchronized Connection conectar() {
        try {
            Class.forName(DRIVER);
            cadena = DriverManager.getConnection(URL, USER, PASSWORD);
            return cadena;
        } catch (ClassNotFoundException | SQLException ex) {
            cadena = null;
            System.err.println("No se pudo conectar con MySQL: " + ex.getMessage());
            return null;
        }
    }

    public synchronized void desconectar() {
        if (cadena != null) {
            try {
                cadena.close();
            } catch (SQLException ex) {
                System.err.println("No se pudo cerrar la conexión: " + ex.getMessage());
            } finally {
                cadena = null;
            }
        }
    }

    public static synchronized Conexion getInstancia() {
        if (instancia == null) {
            instancia = new Conexion();
        }
        return instancia;
    }
}

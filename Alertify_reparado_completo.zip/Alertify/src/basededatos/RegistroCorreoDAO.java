package basededatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/** Registro y autenticación de usuarios, además de la bitácora de accesos. */
public class RegistroCorreoDAO {

    public boolean registrar(String correo, char[] password) throws SQLException, Exception {
        Connection conexion = obtenerConexion();
        boolean autoCommit = conexion.getAutoCommit();
        conexion.setAutoCommit(false);
        try {
            String hash = PasswordUtil.generarHash(password);
            try (PreparedStatement ps = conexion.prepareStatement(
                    "INSERT INTO usuarios_login (correo, password_hash) VALUES (?, ?)")) {
                ps.setString(1, correo.trim().toLowerCase());
                ps.setString(2, hash);
                ps.executeUpdate();
            }
            guardarIntento(conexion, correo, "REGISTRO", true);
            conexion.commit();
            return true;
        } catch (Exception ex) {
            conexion.rollback();
            if (ex instanceof SQLException) throw (SQLException) ex;
            throw (Exception) ex;
        } finally {
            try {
                conexion.setAutoCommit(autoCommit);
            } finally {
                conexion.close();
            }
        }
    }

    public boolean iniciarSesion(String correo, char[] password) throws SQLException, Exception {
        Connection conexion = obtenerConexion();
        try {
            String hash = null;
            try (PreparedStatement ps = conexion.prepareStatement(
                    "SELECT password_hash FROM usuarios_login WHERE correo = ? LIMIT 1")) {
                ps.setString(1, correo.trim().toLowerCase());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) hash = rs.getString("password_hash");
                }
            }
            boolean valido = hash != null && PasswordUtil.verificar(password, hash);
            guardarIntento(conexion, correo, "INICIO_SESION", valido);
            return valido;
        } finally {
            conexion.close();
        }
    }

    private Connection obtenerConexion() throws SQLException {
        Connection conexion = Conexion.getInstancia().conectar();
        if (conexion == null) throw new SQLException("No fue posible conectarse a MySQL.");
        return conexion;
    }

    private void guardarIntento(Connection conexion, String correo, String tipo, boolean exitoso) throws SQLException {
        String sql = "INSERT INTO registro_correos (correo, tipo_acceso, exitoso) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, correo.trim().toLowerCase());
            ps.setString(2, tipo);
            ps.setBoolean(3, exitoso);
            ps.executeUpdate();
        }
    }
}
